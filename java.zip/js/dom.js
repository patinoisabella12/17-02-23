console.log("Entramos");

var items=document.getElementsByClassName("item");

var cantidad = items.length; 

console.log("cantidad de listas" + cantidad);

var div = document.createElement("div");

div;

div.innerText="aprendiendo javascript";

var divUno=document.getElementById("uno")

divUno.appendChild(div);

var lista= document.getElementById("lista")

var hijo = document.createElement("li");
hijo.innerText = "li nuevo";
lista.appendChild(hijo);
 
document.getElementById("tres").style.color="red";
document.getElementById("lista").style.color="green";
 
var cuerpo=document.getElementById("cuerpo");
var div=document.createElement("div");
cuerpo.appendChild (div);
var texto=document.createElement("P")
texto.innerText="Hace mucho tiempo, los gigantes vivían entre las montañas solitarias de Alsacia. En la cima de la montaña más alta, había un castillo llamado Burg Niedeck y era ahí donde el más poderoso de los gigantes vivía con su esposa y su hija llamada Frida.Frida, que era tan alta como el campanario de una iglesia recorría las montañas con toda libertad, pero sabía que nunca debía acercase al valle donde vivían las personas pequeñas.Estas personas eran campesinos que labraban la tierra y plantaban maíz, trigo y cebada. También podaban sus viñas y cavaban zanjas, cosas que los gigantes no podían hacer. Por esta razón, los gigantes tomaban parte de lo que las pequeñas personas cosechaban. Y lo hacían a escondidas, sin dejar rastro, pues según el hechizo, el día en que un campesino llegara hasta Burg Niedeck sería el fin de todos los gigantes. Sin embargo, Burg Niedeck era muy difícil de alcanzar y a ningún campesino se le había ocurrido llegar hasta allá."
div.appendChild(texto)



















































































